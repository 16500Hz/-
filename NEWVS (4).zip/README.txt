Welcome to LaoHax!

To use, please close your anti virus and run LAOHAX.exe.

You will be prompted to enter your forum login, do so and you will be good to go!

Have fun,
-LaoHaxx Development