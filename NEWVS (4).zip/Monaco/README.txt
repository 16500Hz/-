You can edit background image in line 1294.
can use .jpg/.gif/.png file

imageSize : 620x299
 
Have fun :)